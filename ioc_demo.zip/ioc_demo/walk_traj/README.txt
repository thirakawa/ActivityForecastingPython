[frame number] [x axis of GT] [y axis of GT] [x axis of obs] [y axis of obs]
